package karmaka;
/**
 * AIDifficulty 枚举定义了不同的人工智能难度级别。
 * 
 * AIDifficulty énumération définit les différents niveaux de difficulté de l'intelligence artificielle.
 */

public enum AIDifficulty {
    SIMPLE, NORMAL
}

