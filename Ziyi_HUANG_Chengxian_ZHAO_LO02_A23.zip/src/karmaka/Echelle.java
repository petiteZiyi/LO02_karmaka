package karmaka;

/**
 * Echelle 枚举代表玩家在游戏中的生命阶段。
 *
 * L'énumération Echelle représente les étapes de la vie d'un joueur dans le jeu.
 */

public enum Echelle {
    Bousier, Serpent, Loup, Singe, Transcendence;
}

