package karmaka;
import java.io.*;

/**
* GameSaver 类提供了保存和加载游戏状态的功能。
* 它使用 Java 的序列化机制来存储和恢复 Partie 对象的状态。
*
* La classe GameSaver offre les fonctionnalités pour sauvegarder et charger l'état d'un jeu.
* Elle utilise le mécanisme de sérialisation de Java pour stocker et restaurer l'état des objets Partie.
*/

public class GameSaver {

	/**
     * 保存游戏状态到文件
     * @param game 要保存的游戏状态。
     * @param filename 保存文件的名称。
     * @throws IOException 如果写入文件时发生错误。
     *
     * Sauvegarde l'état du jeu dans un fichier.
     * @param game l'état du jeu à sauvegarder.
     * @param filename le nom du fichier de sauvegarde.
     * @throws IOException si une erreur se produit lors de l'écriture dans le fichier.
     */
    public static void saveGame(Partie game, String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(game);
        }
    }

    /**
     * 从文件加载游戏状态。
     * @param filename 要加载的文件名称。
     * @return 加载的游戏状态。
     * @throws IOException 如果读取文件时发生错误。
     * @throws ClassNotFoundException 如果找不到序列化对象的类。
     *
     * Charge l'état du jeu à partir d'un fichier.
     * @param filename le nom du fichier à charger.
     * @return l'état du jeu chargé.
     * @throws IOException si une erreur se produit lors de la lecture du fichier.
     * @throws ClassNotFoundException si la classe de l'objet sérialisé n'est pas trouvée.
     */
    public static Partie loadGame(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (Partie) in.readObject();
        }
    }
}
