package karmaka;

import java.util.*;
import java.io.Serializable;
import cards.*;

public class JeuCartes implements Serializable {
    // attributs d'un jeu de cartes
    private LinkedList<Carte> tasCartes;

    // constructeur du jeu de cartes构造函数
    public JeuCartes() {
			/* instancie le jeu de cartes 不确定这句对不对
			JeuCartes jeu_carte=new  JeuCartes();
			Valeur[] v=Valeur.values(); // ici values renvoie un tableau de Valeur  这里values返回一个牌的分值的数组
			Couleur[] c=Couleur.values(); // ici values renvoie un tableau de Couleur
			*/

        //生成牌
        tasCartes = new LinkedList<Carte>();

        for (int i = 0; i < 5; i++) {
            Embody embody = new Embody();
            tasCartes.add(embody);
        }

        for (int i = 0; i < 3; i++) {
            Peek pe = new Peek();
            tasCartes.add(pe);
            Destiny des = new Destiny();
            tasCartes.add(des);
            StolenDreams st = new StolenDreams();
            tasCartes.add(st);
            Denial de = new Denial();
            tasCartes.add(de);
            Longevity longevity = new Longevity();
            tasCartes.add(longevity);
            Transmigrate transmigrate = new Transmigrate();
            tasCartes.add(transmigrate);
            Sowing sowing = new Sowing();
            tasCartes.add(sowing);
            Roulette roulette = new Roulette();
            tasCartes.add(roulette);
            Salvage salvage = new Salvage();
            tasCartes.add(salvage);
            Recycle recycle = new Recycle();
            tasCartes.add(recycle);
            Panic panic = new Panic();
            tasCartes.add(panic);
            Dwindle dwindle = new Dwindle();
            tasCartes.add(dwindle);
            Anotherday anotherday = new Anotherday();
            tasCartes.add(anotherday);
            Crisis crisis = new Crisis();
            tasCartes.add(crisis);
            HellsHeart hellsHeart = new HellsHeart();
            tasCartes.add(hellsHeart);
        }

        for (int i = 0; i < 2; i++) {
            Swindle sw = new Swindle();
            tasCartes.add(sw);
            Thievery th = new Thievery();
            tasCartes.add(th);
            Vengeance vengeance = new Vengeance();
            tasCartes.add(vengeance);
            Spite spite = new Spite();
            tasCartes.add(spite);
            Jubilee jubilee = new Jubilee();
            tasCartes.add(jubilee);
            Journey journey = new Journey();
            tasCartes.add(journey);
            Mimic mimic = new Mimic();
            tasCartes.add(mimic);
        }
    }

    // retire la premiére carte du tas de cartes (la carte du dessus)
    public Carte distribuerUneCarte() {
        return tasCartes.poll();
    }

    public void ajouterCarte(Carte carte) {
        tasCartes.addLast(carte);
    }

    // 洗牌
    //Mélange de toutes les cartes.
    public void melanger() {
        Collections.shuffle(tasCartes);
    }


    public boolean estVide() {
        return tasCartes.isEmpty();
    }

    public String toString() {
        return tasCartes.toString();
    }

    public LinkedList<Carte> getTasCartes() {
        return tasCartes;
    }


}
