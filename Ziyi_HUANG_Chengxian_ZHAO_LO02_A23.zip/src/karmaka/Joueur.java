package karmaka;
import java.util.*;

/**
 * Joueur 类代表游戏中的一个玩家，包含玩家的基本信息和游戏状态。
 * 玩家可以是人类玩家或AI玩家，并具有不同的游戏策略。
 *
 * La classe Joueur représente un joueur dans le jeu, contenant des informations de base et l'état du jeu du joueur.
 * Un joueur peut être un joueur humain ou un joueur IA et possède différentes stratégies de jeu.
 */
public class Joueur {
    // attributs d'un joueur *** 还需要创建一个弃牌区***
    private String nom;
    private int points;
    private AIStrategy strategy;
    private boolean isAI;
    private Echelle echelle;
    private int anneaux; // 环的数量
    private LinkedList<Carte> main;//手牌
    private LinkedList<Carte> pile;//摸牌的那个区
    private LinkedList<Carte> oeuvres;//积累积分的那个区
    private LinkedList<Carte> future;

    // constructeur构造函数(玩家的初始化）
    public Joueur(String nom) {
        // initialise le nom du joueur
        this.nom = nom;
        this.main = new LinkedList<Carte>();
        this.pile = new LinkedList<Carte>();
        this.oeuvres = new LinkedList<Carte>();
        this.future = new LinkedList<Carte>();
        this.echelle = Echelle.Bousier;
        this.anneaux = 0;
        this.points = 0;
    }

    public void setStrategy(AIStrategy strategy) {
        this.strategy = strategy;
        this.isAI = true;
    }

    public boolean isAI() {
        return isAI;
    }

    public AIStrategy getStrategy() {
        return strategy;
    }

    // 将Valeur枚举转换为点数
    //Conversion des énumérations de valeurs en points
    private int valeurToPoint(Valeur valeur) {
        switch (valeur) {
            case un:
                return 1;
            case doux:
                return 2;
            case trois:
                return 3;
            default:
                return 0; 
        }
    }

    // 计算玩家的oeuvres的分数
    //Calculer le score des œuvres du joueur
    public int calculatePoints() {
        Map<Couleur, Integer> colorPointsSum = new HashMap<>();
        // 用于记录Mosaique颜色牌的点数总和
        //Utilisé pour enregistrer les totaux de points pour les cartes de couleur Mosaique
        int mosaicPoints = 0; 

        for (Carte carte : this.oeuvres) {
            Couleur color = carte.getCouleur();
            // 获取牌的点数
            //Obtenir les points d'une carte
            int points = valeurToPoint(carte.getValeur()); 

            if (color == Couleur.Mosaique) {
            	// 累加Mosaique颜色的点数
            	//Accumulation de points pour les couleurs de la mosaïque
                mosaicPoints += points; 
            } else {
                colorPointsSum.put(color, colorPointsSum.getOrDefault(color, 0) + points);
            }
        }

        // 将Mosaique颜色的点数添加到每种颜色的总分中
        //Ajout de points de couleur Mosaique au total de chaque couleur
        for (Couleur color : Couleur.values()) {
            if (color != Couleur.Mosaique) {
                colorPointsSum.put(color, colorPointsSum.getOrDefault(color, 0) + mosaicPoints);
            }
        }

        // 找出最高分
        //Trouver le meilleur score
        return Collections.max(colorPointsSum.values());
    }

    // 转世Reincarnation方法  ***注意重生结束后需要把未来生命区拿过来，如果不够6张还要摸牌***
    public void reincarnation(Partie partie) {
        int pointsNeeded = 0;
        switch (this.echelle) {
            case Bousier:
                pointsNeeded = 4;
                break;
            case Serpent:
                pointsNeeded = 5;
                break;
            case Loup:
                pointsNeeded = 6;
                break;
            case Singe:
                pointsNeeded = 7;
                break;
            default:
                break;
        }

        int totalPoints = calculatePoints(); // 计算Oeuvres的分数

        // 如果分数不够晋级，尝试使用环
        //Si le score n'est pas suffisant pour avancer, essayez d'utiliser l'anneau
        if (totalPoints < pointsNeeded && this.anneaux > 0) {
            int anneauxNeeded = pointsNeeded - totalPoints; // 需要的环的数量Nombre d'anneaux nécessaires
            int anneauxToUse = Math.min(this.anneaux, anneauxNeeded); // 实际使用的环的数量Nombre d'anneaux effectivement utilisés

            totalPoints += anneauxToUse; // 使用环增加分数Utilisez l'anneau pour augmenter votre score
            this.anneaux -= anneauxToUse; // 减去使用的环Moins d'anneaux utilisés
        }

        // 判断是否能够晋级
        //Juger si vous pouvez avancer ou non
        if (totalPoints >= pointsNeeded) {
            // 晋级逻辑
        	//Logique de promotion
            switch (this.echelle) {
                case Bousier:
                    this.echelle = Echelle.Serpent;
                    break;
                case Serpent:
                    this.echelle = Echelle.Loup;
                    break;
                case Loup:
                    this.echelle = Echelle.Singe;
                    break;
                case Singe:
                    this.echelle = Echelle.Transcendence;
                    break;
                default:
                    break;
            }
            System.out.println(this.nom + " a réussi à passer à la prochaine étape.");
        } else {
        	// 晋级失败时增加一个环
        	//Ajoutez un anneau lorsque vous ne parvenez pas à avancer
            this.anneaux++; 
            System.out.println(this.nom + " n'a pas réussi à passer à la prochaine étape mais a gagné un anneaux.");
        }

        // 打印玩家的分数、当前阶段和环的数量
        //Imprimer le score du joueur, l'étape en cours et le nombre d'anneaux.
        System.out.println("Il a maintenant " + this.calculatePoints() + " points et " + this.anneaux +
                " anneaux après la réincarnation.");
        System.out.println("Il est maintenant au niveau: " + this.echelle);

        while (!this.oeuvres.isEmpty()) {
            Carte carte = this.oeuvres.removeFirst();
            // 使用Partie类的方法添加到Fosse
            //Ajouter à Fosse en utilisant les méthodes de la classe Partie
            partie.ajouterFosse(carte); 
        }

        // 将Future区域的牌移到手牌
        //Déplacez des cartes de la zone Futur vers votre main.
        this.main.addAll(this.future);
        this.future.clear();

        // 补充手牌和Pile区域
        //Réapprovisionner la zone des mains et des piles
        while (this.getMain().size() + this.getPile().size() < 6) {
            if (partie.getJeuCartes().estVide()) {
            	// 如果牌堆已空，停止摸牌
            	//Si la pile est vide, arrêtez de tirer des cartes
                break; 
            }
            Carte carte = partie.getJeuCartes().distribuerUneCarte();
            this.ramasserCartePile(carte);
        }
        // 打印玩家的状态
        //Impression du statut du joueur
        System.out.println(this.nom + " a maintenant " + this.getMain().size() + " cartes dans sa main et "
                + this.getPile().size() + " cartes dans sa pile après la réincarnation.");
    }


    // le joueur ramasse la carte et l'ajoute en dessous des cartes déjà existantes dans la main
    public void ramasserCarteMain(Carte carte) {
        this.main.add(carte);
    }

    public void ramasserCartePile(Carte carte) {
        this.pile.add(carte);
    }

    public void ramasserCarteOeuvre(Carte carte) {
        this.oeuvres.add(carte);
    }

    public void ramasserCarteFuture(Carte carte) {
        this.future.add(carte);
    }

    // retireCarte，玩家移除一张牌
    public void retireMain(Carte carte) {
        main.remove(carte);
    }

    public void retirePile(Carte carte) {
        pile.remove(carte);
    }


    public Carte retireMain() {
        return main.removeFirst();
    }

    public Carte retireOeuvres() {
        return oeuvres.removeFirst();
    }

    public Carte retireFuture() {
        return future.removeFirst();
    }

    public Carte retireFutureRandom() {
        if (future.isEmpty()) {
            System.out.println("Le futur de " + this.nom + " est vide. Aucune carte à retirer.");
            return null;
        }
        Random random = new Random();
        // 生成一个随机索引
        //Générer un index aléatoire
        int randomIndex = random.nextInt(future.size()); 
        // 获取随机索引对应的牌
        //Obtenir la carte correspondant à l'index aléatoire
        Carte carte_selected = future.get(randomIndex); 
        future.remove(carte_selected);
        System.out.println(this.nom + " retire une " + carte_selected + " de sa future.");
        return carte_selected;
    }

    // le joueur gagne s'il a toutes les cartes dans sa main.
    // JeuCartes.nbrCartes représente toutes les cartes
    public boolean isWinner() {
        boolean jaigagne = false;
        if (main.size() == 32)
            jaigagne = true;
        return jaigagne;
    }

    // 获取玩家当前进化阶梯位置的方法
    public Echelle getEchelle() {
        return this.echelle;
    }

    public LinkedList<Carte> getMain() {
        return main;
    }

    public int getNumberMain() {
        return main.size();
    }

    public LinkedList<Carte> getPile() {
        return pile;
    }

    public int getNumberPile() {
        return pile.size();
    }

    public LinkedList<Carte> getOeuvres() {
        return oeuvres;
    }

    public String getNom() {
        return nom;
    }

    public LinkedList<Carte> getFuture() {
        return future;
    }

    // Description d'un joueur avec sa main
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("\n***************************************************\n");
        sb.append(nom).append(" a ").append(main.size()).append(" cartes dans sa main.\n");
        sb.append("main de cartes:").append(main);
        sb.append("\n").append(nom).append(" a ").append(oeuvres.size()).append(" cartes dans ses oeuvres.\n");
        sb.append("oeuvres de cartes:").append(oeuvres);
        sb.append("\n***************************************************\n");
        return sb.toString();
    }
}