package karmaka;

/**
 * AIStrategy 接口定义了人工智能在游戏中的策略执行方式。
 * 它包含了一个方法，用于执行一个游戏回合。
 *
 * L'interface AIStrategy définit la manière dont l'intelligence artificielle exécute sa stratégie dans le jeu.
 * Elle contient une méthode pour exécuter un tour de jeu.
 */

public interface AIStrategy {
    /**
     * 执行人工智能的一个游戏回合。
     * @param aiPlayer 表示人工智能玩家的对象。
     * @param game 表示当前游戏状态的对象。
     *
     * Exécute un tour de jeu pour l'intelligence artificielle.
     * @param aiPlayer l'objet représentant le joueur IA.
     * @param game l'objet représentant l'état actuel du jeu.
     */
    void executeTurn(Joueur aiPlayer, Partie game);
}
