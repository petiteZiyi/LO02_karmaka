//控制整个游戏，判断游戏是否结束
package karmaka;

import java.util.*;
import java.util.Random;
import java.util.Scanner;
import java.io.Serializable;

/**
 * Partie 类控制整个游戏的流程，包括游戏的初始化、玩家的添加、卡牌的分发以及游戏的进行。
 * 它使用单例模式确保游戏实例的唯一性。
 * <p>
 * La classe Partie contrôle le déroulement du jeu, incluant l'initialisation du jeu, l'ajout des joueurs, la distribution des cartes, et la progression du jeu.
 * Elle utilise le modèle Singleton pour assurer l'unicité de l'instance de jeu.
 */
public class Partie implements Serializable {
    // attributs d'une Partie
    // 游戏相关的属性
    private ArrayList<Joueur> listJ;
    private JeuCartes jeu_carte;
    private LinkedList<Carte> fosse; // 共享的废牌区
    private boolean isover = false;

    // 私有静态成员变量，用于保存唯一实例
    //Variable membre statique privée pour contenir les instances uniques
    private static Partie instance;

    // constructeur de Partie
    //构造函数为 private，防止外部实例化
    //Le constructeur est privé afin d'éviter toute instanciation externe.
    private Partie() {
        listJ = new ArrayList<Joueur>();
        jeu_carte = new JeuCartes();
        this.fosse = new LinkedList<>();
        //début du jeu
        isover = false;
    }


    // 公共静态方法，获取唯一实例
    //Méthode statique publique pour obtenir une instance unique
    public static Partie getInstance() {
        // 如果实例不存在，则创建一个新实例
        //Si l'instance n'existe pas, une nouvelle instance est créée.
        if (instance == null) {
            instance = new Partie();
        }
        // 返回实例
        //Retour à l'instance
        return instance;
    }

    public void ajouterUnJoueur() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ajouter un joueur virtuel ? (oui/non)");
        String reponse = scanner.nextLine();
        if (reponse.equalsIgnoreCase("oui")) {
            // 选择AI难度级别
            //Sélectionner le niveau de difficulté de l'IA
            System.out.println("Choisissez la difficulté de l'IA: 1 pour Simple, 2 pour Normal");
            int difficulte = scanner.nextInt();
            AIDifficulty aiDifficulty = (difficulte == 1) ? AIDifficulty.SIMPLE : AIDifficulty.NORMAL;

            // 创建AI玩家并设置策略
            //Créer des joueurs IA et mettre en place des stratégies
            Joueur aiPlayer = new Joueur("AI Player");
            //Définir la stratégie en matière d'IA
            //设置AI策略
            aiPlayer.setStrategy(new RandomAIStrategy(aiDifficulty));
            listJ.add(aiPlayer);

            // 清除scanner的行结束符号
            //Effacer les symboles de fin de ligne pour le scanner
            scanner.nextLine();

            // 添加第二个真人玩家
            //Ajouter un deuxième lecteur en direct
            System.out.println("Le nom du joueur humain est:");
            String nomHumain = scanner.nextLine();
            Joueur joueurHumain = new Joueur(nomHumain);
            listJ.add(joueurHumain);
        } else {
            // 添加两个真人玩家
            //Ajouter deux joueurs en direct
            for (int i = 0; i < 2; i++) {
                System.out.println("Le nom du joueur " + (i + 1) + " est:");
                String nom = scanner.nextLine();
                Joueur joueur = new Joueur(nom);
                listJ.add(joueur);
            }
        }
    }


    //Fournir des méthodes pour obtenir la listeJ
    public void getJoueur() {
        Iterator<Joueur> itJ = listJ.iterator();
        while (itJ.hasNext()) {
            Joueur joueur = itJ.next();
            System.out.println(joueur);
        }
    }


    public Joueur getAuterJoueur(Joueur j1) {
        Iterator<Joueur> it = listJ.iterator();
        while (it.hasNext()) {
            Joueur jou_autre = it.next();
            if (!jou_autre.equals(j1)) {
                return jou_autre;
            }
        }
        return null;
    }

    public JeuCartes getJeuCartes() {
        return jeu_carte;
    }

    public LinkedList<Carte> getFosse() {
        return fosse;
    }

    public void ajouterFosse(Carte carte) {
        fosse.add(carte); // 添加到fosse的顶部
    }


    // On mélange le jeu puis on on distribue les cartes aux joueurs（洗牌+发牌）
    public void distribuerCartes() {
        Iterator<Joueur> it = listJ.iterator();
        while (jeu_carte.estVide() == false && it.hasNext()) {
            Joueur j = it.next();
            while (j.getNumberMain() < 4 || j.getNumberPile() < 2) {
                //on sort une carte du jeu获取并移除牌堆中的第一张牌
                Carte premiere = jeu_carte.distribuerUneCarte();
                //le joueur pointé par l'itérateur ramasse la carte被迭代器指向的玩家将这张牌拿走并放入手牌中
                if (j.getNumberMain() < 4) {
                    j.ramasserCarteMain(premiere);
                } else if (j.getNumberPile() < 2) {
                    j.ramasserCartePile(premiere);
                }
            }
        }
        System.out.println("Les cartes ont été distribuées.");
    }

    //选定使用的牌和使用的方法
    //Sélection des cartes à utiliser et méthode d'utilisation
    public void jou(Joueur j) {
        if (j.isAI()) {
            // 显示当前玩家的名字和他们手中的牌,还有oeuvres中的牌
            //Affiche le nom du joueur actuel et les cartes qu'il a en main, ainsi que les cartes qui se trouvent dans les œuvres.
            System.out.println(j.getNom() + " a maintenant ces cartes en main : " + j.getMain());
            System.out.println("Les cartes dans les œuvres sont : " + j.getOeuvres());
            System.out.println("Point de la zone des Oeuvres: " + j.calculatePoints()); // 显示玩家Oeuvres区域的分数Affiche le score de la zone Oeuvres du joueur.
            System.out.println("Les cartes dans la pile sont : " + j.getPile());
            System.out.println("Les cartes dans la future sont : " + j.getFuture());
            j.getStrategy().executeTurn(j, this);
        } else {
            String choisi;
            String but;
            Scanner scanner = new Scanner(System.in);

            // 显示当前玩家的名字和他们手中的牌,还有oeuvres中的牌
            //Affiche le nom du joueur actuel et les cartes qu'il a en main, ainsi que les cartes qui se trouvent dans les œuvres.
            System.out.println(j.getNom() + " a maintenant ces cartes en main : " + j.getMain());
            System.out.println("Les cartes dans les œuvres sont : " + j.getOeuvres());
            System.out.println("Point de la zone des Oeuvres: " + j.calculatePoints());
            System.out.println("Les cartes dans la pile sont : " + j.getPile());
            System.out.println("Les cartes dans la future sont : " + j.getFuture());
            if (!j.getPile().isEmpty()) { // 检查牌堆是否为空Vérifier si la pile est vide
                System.out.println("Voulez-vous passer votre tour ? (oui/non)");
                String reponse = scanner.nextLine();
                if (reponse.equalsIgnoreCase("oui")) {
                    //Si le joueur choisit de passer son tour, il retourne directement à l'écran d'accueil.
                    // 如果玩家选择跳过回合，直接返回
                    return;
                }
            }
            System.out.println("Sélectionnez la carte que vous souhaitez utiliser: (Indiquer la position correspondante de la carte)");
            choisi = scanner.nextLine();
            // 将玩家输入的位置转换为整数
            //Convertit la position saisie par le joueur en un nombre entier
            int choisi_number = Integer.parseInt(choisi);

            // 用于检查玩家是否做出了有效选择的标志
            //Drapeaux utilisés pour vérifier si le joueur a fait un choix valide
            boolean choixValide = false;
            while (!choixValide) {
                System.out.println("Sélectionnez le but que vous souhaitez utiliser(Choisissez parmi ces trois mots: points, pouvoir ou future)");
                but = scanner.nextLine();

                switch (but) {
                    case "points":
                        j.ramasserCarteOeuvre(j.getMain().get(choisi_number - 1));
                        //Retirez les cartes utilisées de votre main
                        // 从手牌中移除使用的卡片
                        j.retireMain(j.getMain().get(choisi_number - 1));
                        choixValide = true;
                        break;
                    case "future":
                        j.ramasserCarteFuture(j.getMain().get(choisi_number - 1));
                        // 从手牌中移除使用的卡片
                        //Retirez les cartes utilisées de votre main
                        j.retireMain(j.getMain().get(choisi_number - 1));
                        choixValide = true;
                        break;
                    case "pouvoir":
                        Carte carteChoisie = j.getMain().get(choisi_number - 1);
                        Joueur adversaire = getAuterJoueur(j);
                        //传递对手玩家，尽管有的卡牌不会对对手玩家进行操作
                        //Passer les joueurs adverses, bien que certaines cartes n'agissent pas sur les joueurs adverses.
                        carteChoisie.fonction(j, adversaire, this);
                        choixValide = true;
                        break;
                    default:
                        System.out.println("\u001B[31mEntrée non valide. Veuillez choisir parmi points, pouvoir ou future.\u001B[0m");
                        break;
                }
            }
        }

    }

    public static void main(String[] args) {
        //获取实例
        //Obtenir l'instance
        Partie partie = Partie.getInstance();
        partie.ajouterUnJoueur();

        // 洗牌
        //mélanger les cartes
        partie.jeu_carte.melanger();
        System.out.println("On a mélangé les cartes.");

        partie.distribuerCartes();
        partie.getJoueur();

        while (partie.isover == false) {
            ListIterator<Joueur> listIterator = partie.listJ.listIterator();
            while (listIterator.hasNext()) {
                Joueur j = listIterator.next();

                //从j这位玩家的pile池中随机抽取一张牌放入手牌.
                //Tirez une carte au hasard dans la pile de j et mettez-la dans votre main.
                if (j.getNumberPile() > 0) {

                    Random random = new Random();
                    int randomIndex = random.nextInt(j.getPile().size());
                    // 返回随机索引位置的元素
                    //Renvoie un élément à une position d'index aléatoire
                    Carte carte_random = j.getPile().get(randomIndex);
                    j.ramasserCarteMain(carte_random);
                    j.retirePile(carte_random);
                    System.out.println("\n" + j.getNom() + " tire une carte nommée "
                            + carte_random.getNom() + " de la pile et la met dans sa main." + "\n");
                }

                // 检测是否需要进行转世
                //Détecter le besoin de réincarnation
                if (j.getMain().isEmpty() && j.getPile().isEmpty()) {
                    j.reincarnation(partie);
                } else {
                    partie.jou(j);
                }

                // 检查玩家是否达到 Transcendence 状态
                //Vérifier si le joueur a atteint la Transcendance
                if (j.getEchelle() == Echelle.Transcendence) {
                    System.out.println(j.getNom() + " a atteint la Transcendance et a gagné la partie !");
                    partie.isover = true;
                    break;
                }
                System.out.println("\u001B[35m*********************************Votre tour est terminé*********************************\u001B[0m\n");
            }
        }
    }
}
