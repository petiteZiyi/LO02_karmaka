package karmaka;

/**
 * Couleur 枚举定义了一系列颜色，用于表示卡牌的颜色。
 * 这些颜色代表不同的类别。
 *
 * L'énumération Couleur définit un ensemble de couleurs utilisées pour représenter les couleurs du jeu.
 * Ces couleurs représentent différentes catégories.
 */

public enum Couleur {
    Rouge, Verte, Bleue, Mosaique;
}
