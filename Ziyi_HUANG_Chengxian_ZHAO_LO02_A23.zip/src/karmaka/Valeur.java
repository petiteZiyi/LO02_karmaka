
package karmaka;

/**
 * Valeur 枚举表示一组有限的、预定义的值。
 * L'énumération Valeur représente un ensemble limité de valeurs prédéfinies.
 * 这个枚举被用来表示牌对应的分值。
 * Cette énumération est utilisée pour représenter le score correspondant à la carte.
 */

public enum Valeur {
    un, doux, trois;
}
