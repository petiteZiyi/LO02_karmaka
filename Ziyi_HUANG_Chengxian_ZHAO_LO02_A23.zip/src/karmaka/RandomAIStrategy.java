package karmaka;
import java.util.List;
import java.util.Random;


/**
 * RandomAIStrategy 类实现了 AIStrategy 接口，定义了基于随机选择的人工智能策略。
 * 根据难度级别，AI会随机选择执行不同的动作。
 *
 * La classe RandomAIStrategy implémente l'interface AIStrategy, définissant une stratégie d'intelligence artificielle basée sur la sélection aléatoire.
 * Selon le niveau de difficulté, l'IA choisira aléatoirement différentes actions à exécuter.
 */

public class RandomAIStrategy implements AIStrategy {
    private AIDifficulty difficulty;

    /**
     * 构造函数，设置AI的难度级别。
     * @param difficulty AI的难度级别
     *
     * Constructeur définissant le niveau de difficulté de l'IA.
     * @param difficulty le niveau de difficulté de l'IA
     */
    public RandomAIStrategy(AIDifficulty difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * 实现AI的回合执行。
     * 根据难度级别和手牌情况，AI会做出不同的选择。
     * @param aiPlayer AI玩家
     * @param game 当前游戏
     *
     * Exécute le tour de l'IA.
     * En fonction du niveau de difficulté et de la situation des cartes en main, l'IA fera différents choix.
     * @param aiPlayer le joueur IA
     * @param game Jeux actuels
     */
    @Override
    public void executeTurn(Joueur aiPlayer, Partie game) {
        Random random = new Random();
        List<Carte> main = aiPlayer.getMain();
        
        // 如果手牌为空，则无法执行回合
        //Si la main est vide, le tour ne peut pas être exécuté
        if (main.isEmpty()) {
            return; 
        }

        // 随机选择一张手牌
        //Sélectionnez au hasard une carte de votre main
        int randomCardIndex = random.nextInt(main.size());
        Carte chosenCard = main.get(randomCardIndex);

        // 根据难度级别决定行为
        //Le comportement est déterminé en fonction du niveau de difficulté
        if (difficulty == AIDifficulty.SIMPLE) {
            // 简单难度：只将牌放入Oeuvres或Future
            if (random.nextBoolean()) {
                aiPlayer.ramasserCarteOeuvre(chosenCard);
            } else {
                aiPlayer.ramasserCarteFuture(chosenCard);
            }
            aiPlayer.retireMain(chosenCard);
        } else {
            // 困难难度：也可以使用牌的功能
            int action = random.nextInt(3);
            switch (action) {
                case 0:
                    aiPlayer.ramasserCarteOeuvre(chosenCard);
                    aiPlayer.retireMain(chosenCard);
                    break;
                case 1:
                    aiPlayer.ramasserCarteFuture(chosenCard);
                    aiPlayer.retireMain(chosenCard);
                    break;
                case 2:
                    Joueur adversaire = game.getAuterJoueur(aiPlayer);
                    chosenCard.fonction(aiPlayer, adversaire, game);
                    break;
                default:
                    break;
            }
        }
    }
}

