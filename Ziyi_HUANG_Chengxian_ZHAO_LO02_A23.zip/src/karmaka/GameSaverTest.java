package karmaka;
import java.io.IOException;
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;


public class GameSaverTest {

   
    public static void main(String[] args) {
    	//获取实例
    	//Obtenir l'instance
        Partie partie = Partie.getInstance();

        // 保存游戏状态
        try {
            GameSaver.saveGame(partie, "gameSave.ser"); // "gameSave.ser" 是保存文件的名字
            System.out.println("État du jeu enregistré");
        } catch (IOException e) {
            System.out.println("Erreur lors de la sauvegarde du jeu: " + e.getMessage());
        }

        // 加载游戏状态
        try {
            Partie loadedGame = GameSaver.loadGame("gameSave.ser");
            System.out.println("État du jeu chargé");
            // 使用 loadedGame 做一些操作
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erreur de chargement du jeu: " + e.getMessage());
        }
    }
    
}