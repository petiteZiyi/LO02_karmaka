package karmaka;
import java.io.Serializable;

/**
 * Carte 抽象类表示一张卡片，包含颜色、值和名称。
 * 这个类提供了卡片的基础属性和一个抽象方法来定义特定的功能。
 *
 * La classe abstraite Carte représente une carte, incluant sa couleur, sa valeur et son nom.
 * Cette classe fournit les propriétés de base d'une carte et une méthode abstraite pour définir une fonctionnalité spécifique.
 */
public abstract class Carte implements Serializable {
    private Couleur couleur;
    private Valeur valeur;
    private String nom;
    
    /**
     * 抽象方法，定义卡片在游戏中的功能。
     * @param jou 当前玩家
     * @param adversaire 对手玩家
     * @param partie 当前游戏
     *
     * Méthode abstraite définissant la fonction de la carte dans le jeu.
     * @param jou le joueur actuel
     * @param adversaire le joueur adversaire
     * @param partie Jeux actuels
     */
    public abstract void fonction(Joueur jou, Joueur adversaire, Partie partie);

    //构造函数，输入为颜色和数值
    // Constructeur avec nom, valeur et couleur
    public Carte(String nom, Valeur valeur, Couleur couleur) {
        this.setCouleur(couleur);
        this.setValeur(valeur);
        this.setNom(nom);
    }

    // 另一个构造函数，仅输入名称
    // Un autre constructeur avec seulement le nom
    public Carte(String nom) {
        this.setNom(nom);
    }

    /**
     * 获取卡片的颜色。
     * @return 卡片的颜色
     *
     * Obtient la couleur de la carte.
     * @return la couleur de la carte
     */
    public Couleur getCouleur() {
        return couleur;

    }

    /**
     * 设置卡片的颜色。
     * @param couleur 要设置的颜色
     *
     * Définit la couleur de la carte.
     * @param couleur la couleur à définir
     */
    public void setCouleur(Couleur couleur) {
        this.couleur = couleur;
    }

    /**
     * 获取卡片的值。
     * @return 卡片的值
     *
     * Obtient la valeur de la carte.
     * @return la valeur de la carte
     */
    public Valeur getValeur() {
        return valeur;
    }

    /**
     * 设置卡片的值。
     * @param valeur 要设置的值
     *
     * Définit la valeur de la carte.
     * @param valeur la valeur à définir
     */
    public void setValeur(Valeur valeur) {
        this.valeur = valeur;
    }

    /**
     * 获取卡片的名称。
     * @return 卡片的名称
     *
     * Obtient le nom de la carte.
     * @return le nom de la carte
     */
    public String getNom() {
        return nom;
    }

    /**
     * 设置卡片的名称。
     * @param nom 要设置的名称
     *
     * Définit le nom de la carte.
     * @param nom le nom à définir
     */
    public void setNom(String nom) {
        this.nom = nom;
    }


    // 输出牌内容的方法
    // Méthode pour afficher le contenu de la carte
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getNom());
        sb.append(" (");
        sb.append(this.valeur);
        sb.append(", ");
        sb.append(this.couleur);
        sb.append(")");
        return sb.toString();
    }
}
