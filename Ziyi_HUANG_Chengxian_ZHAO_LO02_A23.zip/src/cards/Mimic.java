package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

public class Mimic extends Carte {
    public Mimic() {
        super("Mimic", Valeur.un, Couleur.Mosaique);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Mimic\". Choisissez un Rival.Copiez le pouvoir de son Oeuvre Exposée.");
        
        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (adversaire.getOeuvres().isEmpty()) {
            System.out.println("Le rival " + adversaire.getNom() + " n'a pas d'oeuvres exposées.");
            return;
        }

        Carte carteChoisie;
        if (jou.isAI()) {
            // AI随机选择一张对手的Oeuvre
            Random random = new Random();
            int choix = random.nextInt(adversaire.getOeuvres().size());
            carteChoisie = adversaire.getOeuvres().get(choix);
        } else {
            // 人类玩家选择一张牌
            System.out.println("Oeuvres de " + adversaire.getNom() + ":");
            for (int i = 0; i < adversaire.getOeuvres().size(); i++) {
                System.out.println((i + 1) + ": " + adversaire.getOeuvres().get(i).getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de l'oeuvre dont vous souhaitez copier le pouvoir:");
            int choixHumain = scanner.nextInt();
            while (choixHumain < 1 || choixHumain > adversaire.getOeuvres().size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choixHumain = scanner.nextInt();
            }
            carteChoisie = adversaire.getOeuvres().get(choixHumain - 1);
        }

        // 执行选定牌的功能
        carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
    }
}
