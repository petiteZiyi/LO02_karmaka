package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

/**
 * 这张卡牌允许玩家丢弃一张手牌，并复制该牌的效果。
 * 
 * Cette carte permet au joueur de se défausser d'une carte de sa main et de copier son effet.
 */
public class Denial extends Carte {
    public Denial() {
        super("Deniel", Valeur.doux, Couleur.Bleue);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Denial\". Défaussez une carte de votre Main. Copiez le pouvoir de cette carte.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (jou.getMain().isEmpty()) {
            System.out.println("Vous n'avez pas de cartes en main à défausser.");
            return;
        }

        Carte carteADefaite;
        if (jou.isAI()) {
            // AI 玩家的决策逻辑（随机选择一张手牌）
        	//Logique de décision du joueur IA (choix aléatoire d'une carte Oeuvre à défausser)
            Random random = new Random();
            int indexChoisi = random.nextInt(jou.getMain().size());
            carteADefaite = jou.getMain().remove(indexChoisi);
        } else {
            // 人类玩家的操作
        	//Opérations des joueurs humains
            System.out.println("Votre main:");
            for (int i = 0; i < jou.getMain().size(); i++) {
                System.out.println((i + 1) + ": " + jou.getMain().get(i).getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à défausser et copier:");
            int choix = scanner.nextInt();
            while (choix < 1 || choix > jou.getMain().size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choix = scanner.nextInt();
            }
            carteADefaite = jou.getMain().remove(choix - 1);
        }

        partie.ajouterFosse(carteADefaite);
        System.out.println("Vous avez défaussé la carte \"" + carteADefaite.getNom() + "\".");
        carteADefaite.fonction(jou, partie.getAuterJoueur(jou), partie);
    }

}
