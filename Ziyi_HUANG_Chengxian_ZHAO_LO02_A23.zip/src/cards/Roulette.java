package cards;
import karmaka.*;

import java.util.Random;
import java.util.Scanner;

public class Roulette extends Carte{
    public Roulette() {
        super("Roulette", Valeur.doux, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Roulette\". Défaussez jusqu’à 2 cartes de votre Main. " +
                "Vous pouvez ensuite puiser à la Source autant de carte(s) + 1.");
        
        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (jou.isAI()) {
            // AI玩家随机决定丢弃的牌数
            Random random = new Random();
            int nombreDeCartesADefauser = random.nextInt(Math.min(2, jou.getMain().size()) + 1);
            for (int i = 0; i < nombreDeCartesADefauser; i++) {
                int carteIndex = random.nextInt(jou.getMain().size());
                Carte carteADefauser = jou.getMain().remove(carteIndex);
                partie.ajouterFosse(carteADefauser);
            }
        } else {
            // 人类玩家的选择
            Scanner scanner = new Scanner(System.in);
            int nombreDeCartesADefauser = Math.min(2, jou.getMain().size());
            for (int i = 0; i < nombreDeCartesADefauser; i++) {
                System.out.println("Votre main:");
                int index = 1;
                for (Carte carte : jou.getMain()) {
                    System.out.println(index++ + ": " + carte.getNom());
                }
                System.out.println("Choisissez le numéro de la carte à défausser ou entrez 0 pour ne pas défausser plus de cartes:");
                int choix = scanner.nextInt();
                if (choix == 0) break;
                while (choix < 1 || choix > jou.getMain().size()) {
                    System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                    choix = scanner.nextInt();
                }
                Carte carteADefauser = jou.getMain().remove(choix - 1);
                partie.ajouterFosse(carteADefauser);
            }
        }

        // 从牌堆中摸取相应数量的牌加一
        int nombreDeCartesAPuiser = Math.min(2, jou.getMain().size()) + 1;
        for (int i = 0; i < nombreDeCartesAPuiser; i++) {
            if (!partie.getJeuCartes().estVide()) {
                Carte cartePiochee = partie.getJeuCartes().distribuerUneCarte();
                jou.ramasserCarteMain(cartePiochee);
            } else {
                System.out.println("La Source est épuisée. Impossible de piocher plus de cartes.");
                break;
            }
        }
    }
}
