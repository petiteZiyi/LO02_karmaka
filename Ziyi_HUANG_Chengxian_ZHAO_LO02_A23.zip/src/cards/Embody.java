package cards;

import karmaka.*;

import java.util.Scanner;

/**
 * 这张卡牌允许玩家选择一张已展示的 "Oeuvre" 卡牌，并复制其功能。
 * Cette carte permet au joueur de choisir une de ses "Oeuvres" exposées et d'en copier la fonction.
 */

public class Embody extends Carte {
    public Embody() {
        super("Embody", Valeur.un, Couleur.Mosaique);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Embody\". Choisissez une de vos Oeuvres. Copiez son pouvoir.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        // 检查玩家的Oeuvres是否为空
        //Vérifier si les Oeuvres du joueur sont vides
        if (jou.getOeuvres().isEmpty()) {
            System.out.println("Vous n'avez pas d'oeuvres exposées.");
            return;
        }

        // 显示玩家的Oeuvres
        //Afficher les Oeuvres des joueurs
        System.out.println("Vos Oeuvres:");
        for (int i = 0; i < jou.getOeuvres().size(); i++) {
            System.out.println((i + 1) + ": " + jou.getOeuvres().get(i).getNom());
        }

        // 让玩家选择一张牌来复制其功能
        //Le joueur doit choisir une carte pour en copier la fonction.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choisissez le numéro de l'oeuvre dont vous souhaitez copier le pouvoir:");
        int choix = scanner.nextInt();
        while (choix < 1 || choix > jou.getOeuvres().size()) {
            System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
            choix = scanner.nextInt();
        }

        // 执行选定牌的功能
        //Exécuter la fonction de la carte sélectionnée
        Carte carteChoisie = jou.getOeuvres().get(choix - 1);
        carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
    }
}
