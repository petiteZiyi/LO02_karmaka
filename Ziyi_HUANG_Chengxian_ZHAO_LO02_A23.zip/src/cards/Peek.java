package cards;
import karmaka.*;
import java.util.Random;
import java.util.Scanner;

public class Peek extends Carte {
    public Peek() {
        super("Peek", Valeur.un, Couleur.Bleue);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Peek\". Regardez la Main d’un rival. Vous pouvez ensuite jouer une autre carte.");
        
        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (jou.isAI()) {
            // AI玩家随机选择一张手牌并执行操作
            Random random = new Random();
            if (!jou.getMain().isEmpty()) {
                int randIndex = random.nextInt(jou.getMain().size());
                Carte carteChoisie = jou.getMain().get(randIndex);
                carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
            }
        } else {
            // 人类玩家的选择
            System.out.println("La main de l'adversaire " + adversaire.getNom() + ": ");
            for (int index = 0; index < adversaire.getMain().size(); index++) {
                Carte carte = adversaire.getMain().get(index);
                System.out.println(carte.getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Sélectionnez la carte que vous souhaitez utiliser:");
            String choisi = scanner.nextLine();
            int choisi_number = Integer.parseInt(choisi);
            boolean choixValide = false;

            while (!choixValide) {
                System.out.println("Sélectionnez le but que vous souhaitez utiliser (points, pouvoir ou future):");
                String but = scanner.nextLine();

                switch (but) {
                    case "points":
                        jou.ramasserCarteOeuvre(jou.getMain().get(choisi_number - 1));
                        jou.retireMain(jou.getMain().get(choisi_number - 1));
                        partie.ajouterFosse(jou.getMain().get(choisi_number - 1));
                        choixValide = true;
                        break;
                    case "future":
                        jou.ramasserCarteFuture(jou.getMain().get(choisi_number - 1));
                        jou.retireMain(jou.getMain().get(choisi_number - 1));
                        partie.ajouterFosse(jou.getMain().get(choisi_number - 1));
                        choixValide = true;
                        break;
                    case "pouvoir":
                        Carte carteChoisie = jou.getMain().get(choisi_number - 1);
                        carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
                        choixValide = true;
                        break;
                    default:
                        System.out.println("\u001B[31mEntrée non valide. Veuillez choisir parmi points, pouvoir ou future.\u001B[0m");
                        break;
                }
            }
        }
    }
}
