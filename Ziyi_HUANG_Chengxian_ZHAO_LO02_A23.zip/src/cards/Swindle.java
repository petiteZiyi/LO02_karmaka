package cards;

import karmaka.*;

import java.util.*;

public class Swindle extends Carte {
    public Swindle() {
        super("swindle", Valeur.trois, Couleur.Bleue);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Swindle\". Regardez 3 cartes de la Main d’un rival ; ajoutez-en une à votre Main.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (adversaire.getMain().isEmpty()) {
            System.out.println("Le rival n'a pas de cartes dans sa main.");
            return;
        }

        if (jou.isAI()) {
            // AI玩家的逻辑
            Random random = new Random();
            int randomIndex = random.nextInt(adversaire.getMain().size());
            Carte carteAjoutee = adversaire.getMain().remove(randomIndex); // 随机选择并移除一张牌
            jou.ramasserCarteMain(carteAjoutee); // 添加到AI玩家的手牌
            System.out.println("La carte \"" + carteAjoutee.getNom() + "\" a été ajoutée à la main de l'AI.");
        } else {
            // 人类玩家的逻辑
            // 选择并显示最多3张手牌
            List<Carte> selectedCards = new ArrayList<>();
            Random random = new Random();
            while (selectedCards.size() < Math.min(3, adversaire.getMain().size())) {
                Carte carte = adversaire.getMain().get(random.nextInt(adversaire.getMain().size()));
                if (!selectedCards.contains(carte)) {
                    selectedCards.add(carte);
                }
            }

            // 显示选中的牌
            System.out.println("Cartes sélectionnées de la main du rival:");
            int index = 1;
            for (Carte carte : selectedCards) {
                System.out.println(index++ + ": " + carte.getNom());
            }

            // 让玩家选择一张
            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à ajouter à votre main:");
            int choix = scanner.nextInt();
            while (choix < 1 || choix > selectedCards.size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choix = scanner.nextInt();
            }

            // 将选中的牌加入玩家手牌并从对手手牌中移除
            Carte carteAjoutee = selectedCards.get(choix - 1);
            adversaire.getMain().remove(carteAjoutee);
            jou.ramasserCarteMain(carteAjoutee);
            System.out.println("Vous avez ajouté la carte \"" + carteAjoutee.getNom() + "\" à votre main.");
        }
    }
}
