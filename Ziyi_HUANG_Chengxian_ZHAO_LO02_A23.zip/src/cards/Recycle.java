package cards;
import karmaka.*;

import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class Recycle extends Carte{
    public Recycle() {
        super("Recycle", Valeur.un, Couleur.Verte);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Recycle\". Ajoutez à votre Vie Future une des 3 dernières cartes de la Fosse.");

        LinkedList<Carte> fosse = partie.getFosse(); // 获取共享废牌区

        if (fosse.isEmpty()) {
            System.out.println("La Fosse est vide. Impossible d'ajouter des cartes à la Vie Future.");
            return;
        }

        if (jou.isAI()) {
            // AI玩家随机选择一张牌加入Vie Future
            Random random = new Random();
            int start = Math.max(0, fosse.size() - 3);
            int choix = random.nextInt(Math.min(3, fosse.size() - start)) + start;
            Carte carteChoisie = fosse.remove(choix);
            jou.ramasserCarteFuture(carteChoisie);
        } else {
            // 人类玩家的选择
            System.out.println("Les dernières cartes de la Fosse:");
            int index = 1;
            int start = Math.max(0, fosse.size() - 3);
            for (int i = start; i < fosse.size(); i++) {
                Carte carte = fosse.get(i);
                System.out.println(index++ + ": " + carte.getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à ajouter à votre Vie Future:");
            int choix = scanner.nextInt();
            while (choix < 1 || choix > index - 1) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choix = scanner.nextInt();
            }

            Carte carteChoisie = fosse.remove(start + choix - 1);
            jou.ramasserCarteFuture(carteChoisie);
        }
        
        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
