package cards;

import karmaka.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * 这张卡牌允许玩家查看源牌堆顶的三张卡牌，并选择最多两张加入到他们的未来生活牌堆中。
 * 
 * Cette carte permet au joueur de voir les trois premières cartes de la pile de la Source et d'en choisir jusqu'à deux à ajouter à leur pile de Vie Future.
 */

public class Destiny extends Carte {
    public Destiny() {
        super("Destiny", Valeur.doux, Couleur.Bleue);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Destiny\". Regardez les 3 premières cartes de la Source ; " +
                "ajoutez-en jusqu’à 2 à votre Vie Future. Replacez le reste dans l'ordre souhaité.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (partie.getJeuCartes().getTasCartes().size() < 3) {
            System.out.println("Pas assez de cartes dans la Source pour utiliser cette carte.");
            return;
        }

        List<Carte> cartesVues = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            cartesVues.add(partie.getJeuCartes().distribuerUneCarte());
        }

        if (jou.isAI()) {
            // AI 玩家的决策逻辑
        	//Logique de décision pour les joueurs IA
            Random random = new Random();
            int nombreDeCartesAChoisir = Math.min(2, cartesVues.size());
            for (int i = 0; i < nombreDeCartesAChoisir; i++) {
                int indexChoisi = random.nextInt(cartesVues.size());
                Carte carteChoisie = cartesVues.remove(indexChoisi);
                jou.ramasserCarteFuture(carteChoisie);
            }
        } else {
            // 人类玩家的操作
        	//Opérations des joueurs humains
            Scanner scanner = new Scanner(System.in);
            for (int i = 0; i < 2; i++) {
                System.out.println("Choisissez une carte (numéro) à ajouter à votre Vie Future, ou entrez 0 pour terminer:");
                int choixIndex = scanner.nextInt();

                if (choixIndex == 0) {
                    break;
                } else if (choixIndex > 0 && choixIndex <= cartesVues.size()) {
                    Carte carteChoisie = cartesVues.remove(choixIndex - 1);
                    jou.ramasserCarteFuture(carteChoisie);

                    if (i == 0 && !cartesVues.isEmpty()) {
                        System.out.println("Les cartes restantes de la Source sont:");
                        for (int j = 0; j < cartesVues.size(); j++) {
                            System.out.println((j + 1) + ": " + cartesVues.get(j).getNom());
                        }
                    }
                } else {
                    System.out.println("\u001B[31mChoix invalide.\u001B[0m");
                    i--;
                }
            }
        }

        for (Carte carteRestante : cartesVues) {
            partie.getJeuCartes().ajouterCarte(carteRestante);
        }
    }

}