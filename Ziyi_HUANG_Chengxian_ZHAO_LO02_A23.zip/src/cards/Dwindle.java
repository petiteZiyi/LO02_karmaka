package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

/**
 * 这张卡牌允许玩家选择一个玩家（包括自己），迫使其丢弃一张手牌。
 * 
 * Cette carte permet au joueur de choisir un joueur (y compris lui-même) et de le forcer à se défausser d'une carte de sa main.
 */
public class Dwindle extends Carte {
    public Dwindle() {
        super("Dwindle", Valeur.un, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Dwindle\". Le joueur de votre choix défausse une carte de sa Main.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        Joueur joueurChoisi;
        int choixCarte;

        if (jou.isAI()) {
            // AI 玩家的决策逻辑
        	//Logique de décision pour les joueurs IA
            // 随机选择对手或自己
        	//Sélectionnez au hasard un adversaire ou vous-même
            Random random = new Random();
            joueurChoisi = random.nextBoolean() ? jou : adversaire;

            // 如果所选玩家的手牌不为空，则随机丢弃一张
            //Si la main du joueur choisi n'est pas vide, défaussez-en un au hasard.
            if (!joueurChoisi.getMain().isEmpty()) {
                choixCarte = random.nextInt(joueurChoisi.getMain().size());
            } else {
            	// 如果所选玩家没有手牌，则直接返回
            	//Si le joueur sélectionné n'a pas de main, celle-ci est renvoyée directement au
                return; 
            }
        } else {
            // 人类玩家操作
        	//Fonctionnement du joueur humain
            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez un joueur (1 pour vous-même, 2 pour l'adversaire):");
            int choixJoueur = scanner.nextInt();
            joueurChoisi = (choixJoueur == 1) ? jou : adversaire;

            // 显示所选玩家的手牌
            //Montre la main du joueur sélectionné
            System.out.println("Main de " + joueurChoisi.getNom() + ":");
            for (int index = 0; index < joueurChoisi.getMain().size(); index++) {
                Carte carte = joueurChoisi.getMain().get(index);
                System.out.println((index + 1) + ". " + carte.getNom());
            }

            // 让玩家从所选玩家的手牌中选择一张丢弃
            //Permet au joueur de choisir une des cartes de la main du joueur choisi pour la défausser.
            System.out.println("Choisissez une carte à défausser:");
            choixCarte = scanner.nextInt() - 1;
            while (choixCarte < 0 || choixCarte >= joueurChoisi.getMain().size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choixCarte = scanner.nextInt() - 1;
            }
        }

        // 从所选玩家的手牌中移除并添加到废牌区
        //Retirer de la main du joueur sélectionné et ajouter à la zone de défausse
        Carte carteToRemove = joueurChoisi.getMain().remove(choixCarte);
        partie.ajouterFosse(carteToRemove);
        System.out.println("La carte \"" + carteToRemove.getNom() + "\" a été défaussée de la main de " + joueurChoisi.getNom());
    }

}
