package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

public class Vengeance extends Carte {
    public Vengeance() {
        super("Vengeance", Valeur.trois, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Vengeance\". Défaussez l’Oeuvre Exposée d’un rival.");

        if (adversaire.getOeuvres().isEmpty()) {
            System.out.println("Le rival n'a pas d'oeuvres à défausser.");
            return;
        }

        if (jou.isAI()) {
            // AI 玩家的逻辑
            Random random = new Random();
            int randomIndex = random.nextInt(adversaire.getOeuvres().size());
            Carte carteToRemove = adversaire.getOeuvres().remove(randomIndex);
            partie.ajouterFosse(carteToRemove);
            System.out.println("La carte \"" + carteToRemove.getNom() + "\" a été défaussée des oeuvres de " + adversaire.getNom() + " et ajoutée à la fosse.");
        } else {
            // 人类玩家的逻辑
            System.out.println("Oeuvres du rival:");
            int index = 1;
            for (Carte carte : adversaire.getOeuvres()) {
                System.out.println(index++ + ": " + carte.getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à défausser:");
            int choix = scanner.nextInt();
            while (choix < 1 || choix > adversaire.getOeuvres().size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choix = scanner.nextInt();
            }

            Carte carteToRemove = adversaire.getOeuvres().remove(choix - 1);
            partie.ajouterFosse(carteToRemove);
            System.out.println("La carte \"" + carteToRemove.getNom() + "\" a été défaussée des oeuvres de " + adversaire.getNom() + " et ajoutée à la fosse.");
        }

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
