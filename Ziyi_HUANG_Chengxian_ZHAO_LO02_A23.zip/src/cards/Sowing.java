package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

public class Sowing extends Carte {
    public Sowing() {
        super("Sowing", Valeur.doux, Couleur.Verte);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Sowing\". Puisez 2 cartes à la Source, puis placez sur votre Vie Future 2 cartes de votre Main.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        JeuCartes jeu_carte = partie.getJeuCartes();
        // 从牌堆中摸两张牌
        for (int i = 0; i < 2; i++) {
            if (!jeu_carte.estVide()) {
                Carte cartePiochee = jeu_carte.distribuerUneCarte();
                jou.ramasserCarteMain(cartePiochee);
            } else {
                System.out.println("La Source est épuisée. Impossible de piocher plus de cartes.");
                break;
            }
        }

        // AI玩家自动选择两张牌放入Future
        if (jou.isAI()) {
            Random random = new Random();
            for (int i = 0; i < 2; i++) {
                if (!jou.getMain().isEmpty()) {
                    int randomIndex = random.nextInt(jou.getMain().size());
                    Carte carteChoisie = jou.getMain().remove(randomIndex);
                    jou.ramasserCarteFuture(carteChoisie);
                }
            }
        } else {
            // 人类玩家的选择
            Scanner scanner = new Scanner(System.in);
            for (int i = 0; i < 2; i++) {
                if (jou.getMain().isEmpty()) {
                    System.out.println("Vous n'avez plus de cartes en main pour placer dans la Vie Future.");
                    break;
                }
                System.out.println("Votre main: ");
                int index = 1;
                for (Carte carte : jou.getMain()) {
                    System.out.println(index++ + ": " + carte.getNom());
                }
                System.out.println("Choisissez le numéro de la carte à placer dans votre Vie Future:");
                int choix = scanner.nextInt();
                while (choix < 1 || choix > jou.getMain().size()) {
                    System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                    choix = scanner.nextInt();
                }

                Carte carteChoisie = jou.getMain().remove(choix - 1);
                jou.ramasserCarteFuture(carteChoisie);
                System.out.println("Vous avez placé " + carteChoisie.getNom() + " dans votre Vie Future.");
            }
        }
    }
}
