package cards;

import karmaka.*;

import java.util.Random;

public class Spite extends Carte {
    public Spite() {
        super("Spite", Valeur.trois, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Spite\". Défaussez au hasard 2 cartes de la Main d’un rival.");

        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            if (adversaire.getMain().isEmpty()) {
                System.out.println("Le rival n'a plus de cartes dans sa main.");
                break; // 如果对手的手牌为空，则退出循环
            }
            int randomIndex = random.nextInt(adversaire.getMain().size());
            Carte carteToRemove = adversaire.getMain().remove(randomIndex); // 随机选择并移除一张牌
            partie.ajouterFosse(carteToRemove); // 将移除的牌加入废牌区
        }

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
