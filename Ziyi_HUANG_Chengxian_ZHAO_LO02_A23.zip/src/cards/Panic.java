package cards;
import karmaka.*;

import java.util.Scanner;

public class Panic extends Carte{
    public Panic() {
        super("Panic", Valeur.un, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Panic\". Défaussez la première carte de la Pile d'un joueur. " +
                "Vous pouvez ensuite jouer une autre carte.");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Choisissez le joueur (1 pour vous-même, 2 pour l'adversaire):");
        int choixJoueur = scanner.nextInt();

        Joueur cible = (choixJoueur == 1) ? jou : adversaire;
        if (cible.getPile().isEmpty()) {
            System.out.println("La Pile de " + cible.getNom() + " est vide. Aucune carte à défausser.");
        } else {
            Carte carteADefauser = cible.getPile().removeFirst();
            partie.ajouterFosse(carteADefauser);
            System.out.println("La première carte de la Pile de " + cible.getNom() + " a été défaussée.");
        }

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        // 选择另一张卡牌进行操作
        System.out.println("Sélectionnez la carte que vous souhaitez utiliser:");
        String choisi = scanner.nextLine();
        int choisi_number = Integer.parseInt(choisi);
        boolean choixValide = false;

        while (!choixValide) {
            System.out.println("Sélectionnez le but que vous souhaitez utiliser (points, pouvoir ou future):");
            String but = scanner.nextLine();

            switch (but) {
                case "points":
                    jou.ramasserCarteOeuvre(jou.getMain().get(choisi_number - 1));
                    choixValide = true;
                    break;
                case "future":
                    jou.ramasserCarteFuture(jou.getMain().get(choisi_number - 1));
                    choixValide = true;
                    break;
                case "pouvoir":
                    Carte carteChoisie = jou.getMain().get(choisi_number - 1);
                    carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
                    choixValide = true;
                    break;
                default:
                    System.out.println("\u001B[31mEntrée non valide. Veuillez choisir parmi points, pouvoir ou future.\u001B[0m");
                    break;
            }
        }
    }
}
