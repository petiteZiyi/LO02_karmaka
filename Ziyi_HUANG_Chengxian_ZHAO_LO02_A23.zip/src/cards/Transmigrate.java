package cards;

import karmaka.*;

public class Transmigrate extends Carte {
    public Transmigrate() {
        super("Transmigrate", Valeur.un, Couleur.Bleue);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Transmigrate\". Placez dans votre Main n’importequelle carte de votre Vie Future.");

        Carte carte = jou.retireFutureRandom(); // 这里retireFuture改成了随机抽取一张牌。
        jou.ramasserCarteMain(carte);

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
