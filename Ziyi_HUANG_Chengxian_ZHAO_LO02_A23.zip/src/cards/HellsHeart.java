package cards;

import karmaka.*;

/**
 * 这张卡牌允许玩家弃掉对手的两张未来生活区域中的牌。
 * 
 * Cette carte permet au joueur de se défausser des deux premières cartes de la zone Vie Future d'un adversaire.
 */
public class HellsHeart extends Carte {
    public HellsHeart() {
        super("HellsHeart", Valeur.doux, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"HellsHeart\". Défaussez les 2 premières cartes de la Vie Future d'un rival.");

        // 检查对手的Vie Future区域中是否有足够的牌
        //Vérifiez si votre adversaire a suffisamment de cartes dans la zone Vie Future.
        int count = Math.min(2, adversaire.getFuture().size());
        for (int i = 0; i < count; i++) {
            // 从对手的Vie Future中移除牌，并添加到废牌区
        	//Retirez des cartes de la Vie Future de votre adversaire et ajoutez-les à la zone de défausse.
            Carte carteToRemove = adversaire.retireFuture();
            if (carteToRemove != null) {
                partie.ajouterFosse(carteToRemove);
                System.out.println("La carte \"" + carteToRemove.getNom() + "\" a été retirée de la Vie Future de " + adversaire.getNom());
            }
        }

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
