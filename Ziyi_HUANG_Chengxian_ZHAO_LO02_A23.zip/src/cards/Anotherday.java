package cards;
import karmaka.*;
import java.util.Random;
import java.util.Scanner;

/**
 * 这张卡牌允许玩家从牌堆抽一张牌，并且可以立即使用另一张卡牌。
 *
 * Cette carte permet au joueur de piocher une carte du paquet et de jouer immédiatement une autre carte.
 */
public class Anotherday extends Carte {
    public Anotherday() {
        super("Anotherday",Valeur.un, Couleur.Verte);
    }

    /**
     * @param jou 当前使用卡牌的玩家
     * @param adversaire 对手玩家
     * @param partie 当前游戏实例
     * 
     * @param jou le joueur qui utilise actuellement la carte
     * @param adversaire Opponent player
     * @param partie Current game instance
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Anotherday\". Puisez une carte à la Source." +
                "Vous pouvez ensuite jouer une autre carte.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        // 从牌堆摸一张牌
        //Tirez une carte de la pioche. 
        if (!partie.getJeuCartes().estVide()) {
            Carte cartePiochee = partie.getJeuCartes().distribuerUneCarte();
            jou.ramasserCarteMain(cartePiochee);
            System.out.println("Vous avez pioché: " + cartePiochee.getNom());
        } else {
            System.out.println("La Source est épuisée. Impossible de piocher une carte.");
        }

        if (jou.isAI()) {
            // AI 玩家的操作逻辑
        	//Logique de fonctionnement du joueur IA
            Random random = new Random();
            int choixIndex = random.nextInt(jou.getMain().size());
            Carte carteChoisie = jou.getMain().get(choixIndex);

            // 随机选择卡牌的用途
            //Sélection aléatoire de l'utilisation des cartes
            int choixBut = random.nextInt(3);
            switch (choixBut) {
                case 0:
                    jou.ramasserCarteOeuvre(carteChoisie);
                    break;
                case 1:
                    jou.ramasserCarteFuture(carteChoisie);
                    break;
                case 2:
                    carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
                    break;
            }
            jou.retireMain(carteChoisie);
            partie.ajouterFosse(carteChoisie);

        } else {
            // 人类玩家的操作逻辑
        	//Logique opérationnelle pour les acteurs humains
            Scanner scanner = new Scanner(System.in);
            System.out.println("Votre main: ");
            for (int i = 0; i < jou.getMain().size(); i++) {
                System.out.println((i + 1) + ": " + jou.getMain().get(i).getNom());
            }

            System.out.println("Sélectionnez une autre carte que vous souhaitez utiliser (indiquez le numéro de la carte):");
            int choixIndex = scanner.nextInt();
            while (choixIndex < 1 || choixIndex > jou.getMain().size()) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choixIndex = scanner.nextInt();
            }

            Carte carteChoisie = jou.getMain().get(choixIndex - 1);
            System.out.println("Sélectionnez le but de la carte (points, pouvoir ou future):");
            scanner.nextLine(); // 清空换行符
            String but = scanner.nextLine();

            switch (but) {
                case "points":
                    jou.ramasserCarteOeuvre(carteChoisie);
                    break;
                case "future":
                    jou.ramasserCarteFuture(carteChoisie);
                    break;
                case "pouvoir":
                    carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
                    break;
                default:
                    System.out.println("\u001B[31mEntrée non valide. Veuillez choisir un numéro valide.\u001B[0m");
                    break;
            }
            jou.retireMain(carteChoisie);
            partie.ajouterFosse(carteChoisie);
        }
    }

}
