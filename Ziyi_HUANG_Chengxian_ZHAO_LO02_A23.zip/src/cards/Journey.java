package cards;

import karmaka.*;

import java.util.Scanner;

/**
 * 这张卡牌使玩家能够从牌堆中抽取三张牌，并允许他们再次执行一次操作。
 * 
 * Cette carte permet au joueur de tirer trois cartes de la pioche et lui donne la possibilité de jouer une autre carte.
 */
public class Journey extends Carte {
    public Journey() {
        super("Journey", Valeur.trois, Couleur.Verte);
    }

     /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Journey\". Puisez 3 cartes à la Source. " +
                "Vous pouvez ensuite jouer une autre carte.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        // 从牌堆中摸三张牌
        // Tirez trois cartes de la pioche.
        for (int i = 0; i < 3; i++) {
            if (!partie.getJeuCartes().estVide()) {
                Carte cartePiochee = partie.getJeuCartes().distribuerUneCarte();
                jou.ramasserCarteMain(cartePiochee);
            } else {
                System.out.println("La Source est épuisée. Impossible de piocher plus de cartes.");
                break;
            }
        }

        // 玩家选择另一张卡牌进行操作
        //Les joueurs choisissent une autre carte à manipuler
        Scanner scanner = new Scanner(System.in);

        // 首先显示出玩家的手牌
        //Montrer d'abord la main du joueur
        System.out.println("Votre main actuelle:");
        for (int i = 0; i < jou.getMain().size(); i++) {
            Carte carte = jou.getMain().get(i);
            System.out.println((i + 1) + ". " + carte.getNom());
        }

        // 让玩家选择一张牌进行操作
        //Laisser le joueur choisir une carte à manipuler
        System.out.println("Sélectionnez la carte que vous souhaitez utiliser (indiquez le numéro):");
        String choisi = scanner.nextLine();
        int choisi_number = Integer.parseInt(choisi);
        boolean choixValide = false;

        while (!choixValide) {
            System.out.println("Sélectionnez le but pour cette carte (points, pouvoir ou future):");
            String but = scanner.nextLine();

            switch (but) {
                case "points":
                    jou.ramasserCarteOeuvre(jou.getMain().get(choisi_number - 1));
                    choixValide = true;
                    break;
                case "future":
                    jou.ramasserCarteFuture(jou.getMain().get(choisi_number - 1));
                    choixValide = true;
                    break;
                case "pouvoir":
                    Carte carteChoisie = jou.getMain().get(choisi_number - 1);
                    carteChoisie.fonction(jou, partie.getAuterJoueur(jou), partie);
                    choixValide = true;
                    break;
                default:
                    System.out.println("\u001B[31mEntrée non valide. Veuillez choisir un numéro valide.\u001B[0m");
                    choisi = scanner.nextLine();
                    choisi_number = Integer.parseInt(choisi);
                    break;
            }
        }
    }
}
