package cards;
import karmaka.*;

import java.util.Scanner;

/**
 * 这张卡牌允许玩家从手牌中选择最多两张卡牌放置到他们的作品区域。
 * 
 * Cette carte permet au joueur de choisir jusqu'à deux cartes de sa main pour les placer dans sa zone d'Oeuvres.
 */
public class Longevity extends Carte{
    public Longevity() {
        super("Longevity", Valeur.doux, Couleur.Verte);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Longevity\". Placez 2 cartes puisées à la Source sur la Pile d'un joueur.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        Scanner scanner = new Scanner(System.in);
        System.out.println("Choisissez le joueur pour recevoir les cartes (1 pour vous-même, 2 pour l'adversaire):");
        int choixJoueur = scanner.nextInt();

        Joueur cible = (choixJoueur == 1) ? jou : adversaire;

        // 从牌堆中抽取两张牌并放入指定玩家的pile
        //Prenez deux cartes de la pile et placez-les dans la pile du joueur désigné.
        for (int i = 0; i < 2; i++) {
            if (partie.getJeuCartes().estVide()) {
                System.out.println("La Source est épuisée. Impossible de piocher plus de cartes.");
                break;
            }
            Carte cartePiochee = partie.getJeuCartes().distribuerUneCarte();
            cible.ramasserCartePile(cartePiochee);
            System.out.println("Une carte a été ajoutée à la Pile de " + cible.getNom() + ".");
        }
    }
}
