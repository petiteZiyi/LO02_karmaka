package cards;
import karmaka.*;

import java.util.Random;
import java.util.Scanner;

/**
 * 这张牌可以让玩家迫使对手从其作品区丢弃一张牌
 * 
 * Cette carte permet au joueur de forcer un adversaire à défausser une carte de leur zone Oeuvres
 */
public class Crisis extends Carte {
    public Crisis() {
        super("Crisis",Valeur.doux, Couleur.Rouge);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Crisis\". Le rival de votre choix défausse une de ses Oeuvres.");

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (adversaire.getOeuvres().isEmpty()) {
            System.out.println("Le rival " + adversaire.getNom() + " n'a pas d'oeuvres à défausser.");
            return;
        }

        Carte carteToRemove;
        if (jou.isAI()) {
            // AI 玩家的决策逻辑（随机选择一张 Oeuvre 牌丢弃）
        	//Logique de décision du joueur IA (choix aléatoire d'une carte Oeuvre à défausser)
            Random random = new Random();
            int indexChoisi = random.nextInt(adversaire.getOeuvres().size());
            carteToRemove = adversaire.getOeuvres().remove(indexChoisi);
        } else {
            // 人类玩家的操作
        	//Opérations des joueurs humains
            System.out.println("Oeuvres de " + adversaire.getNom() + ":");
            for (int i = 0; i < adversaire.getOeuvres().size(); i++) {
                System.out.println((i + 1) + ": " + adversaire.getOeuvres().get(i).getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à défausser:");
            int choix = scanner.nextInt();
            while (choix < 1 || choix > adversaire.getOeuvres().size()) {
                System.out.println("\u001B[31mChoix invalide.\u001B[0m");
                choix = scanner.nextInt();
            }
            carteToRemove = adversaire.getOeuvres().remove(choix - 1);
        }

        partie.ajouterFosse(carteToRemove);
        System.out.println("La carte \"" + carteToRemove.getNom() + "\" a été défaussée des oeuvres de " + adversaire.getNom() + " et ajoutée à la fosse.");
    }

}
