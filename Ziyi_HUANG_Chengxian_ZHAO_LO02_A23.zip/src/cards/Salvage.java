package cards;
import karmaka.*;

import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class Salvage extends Carte{
    public Salvage() {
        super("Salvage", Valeur.doux, Couleur.Verte);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Salvage\". Ajoutez à votre Main une des 3 dernières cartes de la Fosse.");

        LinkedList<Carte> fosse = partie.getFosse(); // 获取共享废牌区

        if (fosse.isEmpty()) {
            System.out.println("La Fosse est vide. Impossible d'ajouter des cartes à la main.");
            return;
        }

        if (jou.isAI()) {
            // AI玩家随机选择一张废牌区的牌
            Random random = new Random();
            int start = Math.max(0, fosse.size() - 3);
            int randomIndex = start + random.nextInt(Math.min(3, fosse.size() - start));
            Carte carteChoisie = fosse.remove(randomIndex);
            jou.ramasserCarteMain(carteChoisie);
            System.out.println("AI玩家从废牌区添加了 " + carteChoisie.getNom() + " 到手牌。");
        } else {
            // 人类玩家的选择
            System.out.println("Les dernières cartes de la Fosse:");
            int index = 1;
            for (int i = Math.max(0, fosse.size() - 3); i < fosse.size(); i++) {
                System.out.println(index++ + ": " + fosse.get(i).getNom());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Choisissez le numéro de la carte à ajouter à votre main:");
            int choix = Integer.parseInt(scanner.nextLine());
            while (choix < 1 || choix > index - 1) {
                System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                choix = Integer.parseInt(scanner.nextLine());
            }

            Carte carteChoisie = fosse.remove(Math.max(0, fosse.size() - 3) + choix - 1);
            jou.ramasserCarteMain(carteChoisie);
            System.out.println("Vous avez ajouté la carte \"" + carteChoisie.getNom() + "\" à votre main depuis la Fosse.");
        }

        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de défausse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 
    }
}
