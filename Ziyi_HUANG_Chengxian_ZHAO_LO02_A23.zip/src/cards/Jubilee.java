package cards;

import karmaka.*;

import java.util.Random;
import java.util.Scanner;

/**
 * 这张卡牌允许玩家从手牌中选择最多两张卡牌放置到他们的oeuvres区域。
 * Cette carte permet au joueur de choisir jusqu'à deux cartes de sa main pour les placer dans sa zone d'Oeuvres.
 */
public class Jubilee extends Carte {
    public Jubilee() {
        super("Jubilee", Valeur.trois, Couleur.Verte);
    }

    /**
     * 当这张卡被使用时，触发其功能。
     * Déclenche la fonction de la carte lorsqu'elle est utilisée.
     * 
     * @param jou 当前玩家对象。
     * @param adversaire 对手玩家对象。
     * @param partie 当前游戏局对象。
     * 
     * @param jou L'objet Joueur actuel.
     * @param adversaire L'objet Joueur de l'adversaire.
     * @param partie L'objet Partie de la partie actuelle.
     */
    public void fonction(Joueur jou, Joueur adversaire, Partie partie) {
        System.out.println("Vous avez utilisé \"Jubilee\". Placez jusqu’à 2 cartes de votre Main sur vos Oeuvres.");
        
        // 将此卡牌加入废牌区
        //Ajouter cette carte à la zone de fosse
        partie.ajouterFosse(this); 
        // 从玩家手牌中移除此卡牌
        //Retirer cette carte de la main du joueur.
        jou.retireMain(this); 

        if (jou.isAI()) {
            // AI随机选择最多两张手牌
        	//L'IA sélectionne au hasard jusqu'à deux cartes dans sa main.
            Random random = new Random();
            int cartesAPlacer = Math.min(2, jou.getMain().size());
            for (int i = 0; i < cartesAPlacer; i++) {
                int randIndex = random.nextInt(jou.getMain().size());
                Carte carteChoisie = jou.getMain().remove(randIndex);
                jou.ramasserCarteOeuvre(carteChoisie);
                System.out.println("AI a placé " + carteChoisie.getNom() + " dans ses Oeuvres.");
            }
        } else {
            // 人类玩家选择手牌
        	//Le joueur humain choisit la carte dans sa main
            Scanner scanner = new Scanner(System.in);
            for (int i = 0; i < 2; i++) {
                if (jou.getMain().isEmpty()) {
                    System.out.println("Vous n'avez plus de cartes en main.");
                    break;
                }

                // 显示玩家手牌
                //Montrer les cartes dans main du joueur
                System.out.println("Votre main: ");
                int index = 1;
                for (Carte carte : jou.getMain()) {
                    System.out.println(index++ + ": " + carte.getNom());
                }

                // 让玩家选择一张放入Oeuvres
                //Laisser le joueur en choisir un qu'il placera dans Oeuvres
                System.out.println("Choisissez le numéro de la carte à placer sur vos Oeuvres (ou entrez 0 pour arrêter):");
                int choix = scanner.nextInt();

                if (choix == 0) {
                    break;
                }

                while (choix < 1 || choix > jou.getMain().size()) {
                    System.out.println("\u001B[31mChoix invalide. Veuillez choisir un numéro valide.\u001B[0m");
                    choix = scanner.nextInt();
                }

                // 将选中的牌加入Oeuvres并从手牌中移除
                //Ajoutez la carte sélectionnée à Oeuvres et retirez-la de votre main.
                Carte carteChoisie = jou.getMain().remove(choix - 1);
                jou.ramasserCarteOeuvre(carteChoisie);
                System.out.println("Vous avez placé " + carteChoisie.getNom() + " dans vos Oeuvres.");
            }
        }
    }
}
